<?php
if($_POST) {

    include '../config/Database.php';
    include '../object/Buku.php';

    $database = new Database();
    $db = $database->getConnection();

    $buku = new Buku($db);

    $buku->ID = $_POST['ID'];
    $buku->ISBN = $_POST['isbn'];
    $buku->Judul = $_POST['judul'];
    $buku->Pengarang = $_POST['pengarang'];
    $buku->Kategori_ID = $_POST['Kategori_ID'];
    $buku->Penerbit_ID = $_POST['penerbit_id'];
    $buku->Deskripsi = $_POST['deskripsi'];
    $buku->Stok = $_POST['stok'];

    $buku->update();
}
header("Location: http://localhost/PERPUS_APP/buku/index.php");
?>
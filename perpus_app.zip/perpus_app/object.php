<?php

class Anggota{
    
    // koneksi database dan nama tabel
    private $conn;
    private $table_name = "Anggota";

    //property object anggota
    public $ID;
    public $NIK;
    public $NamaLengkap;
    public $Alamat;
    public $NoTelp;
    public $TglRegistrasi;

    public function __construrct($db) {
        $this->conn = $db;
    }

    function create() {
        //insert
        $query = "INSERT INTO" . $this->table_name . " (NIK, NamaLengkap, Alamat, Notelp, TglRegistrasi)" .
                                " VALUES (:NIK, :NamaLengkap, :Alamat, :NoTelp, :TglRegistrasi)";
        
        $result = $this->conn->prepare($query);

        $this->NIK = htmlspecialchars(strip_tags($this->NIK));
        $this->NamaLengkap = htmlspecialchars(strip_tags($this->NamaLengkap));
        $this->Alamat = htmlspecialchars(strip_tags($this->Alamat));
        $this->NoTelp = htmlspecialchars(strip_tags($this->NoTelp));
        $this->TglRegistrasi = date("Y-m-d");

        $result->bindParam(":NIK", $this->NIK);
        $result->bindParam(":NamaLengkap", $this->NamaLengkap);
        $result->bindParam(":Alamat", $this->Alamat);
        $result->bindParam(":NoTelp", $this->NoTelp);
        $result->bindParam(":TglRegistrasi", $this->TglRegistrasi);

        if($result->execute()){
            return true;    
        } else{
            return false
        }
    }
}